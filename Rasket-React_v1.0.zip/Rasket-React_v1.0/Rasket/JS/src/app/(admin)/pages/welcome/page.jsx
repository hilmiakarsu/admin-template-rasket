import PageMetaData from '@/components/PageTitle';
const Welcome = () => {
  return <>
      <PageMetaData title="Welcome" />
    </>;
};
export default Welcome;