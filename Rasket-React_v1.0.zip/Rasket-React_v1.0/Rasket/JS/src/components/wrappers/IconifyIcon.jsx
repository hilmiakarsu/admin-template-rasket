import { Icon } from '@iconify/react';
const IconifyIcon = props => {
  return <Icon {...props} />;
};
export default IconifyIcon;